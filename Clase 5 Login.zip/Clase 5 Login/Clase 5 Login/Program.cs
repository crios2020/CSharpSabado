﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_5_Login
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
           * Mi primer Login.
           * Ingresar por consola el usuario y clave.
           */

            String[] users = {"Juan", "Maria", "Jose", "Ana" };
            String[] claves = { "123" , "abc"  , "321" , "111" };

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("***********************************************************");
            Console.WriteLine("*       B I E N V E N I D O S                             *");
            Console.WriteLine("***********************************************************");
            Console.WriteLine();
            Console.Write("Ingrese su Usuario: ");
            string user = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Ingrese su Clave: ");
            string pass = Console.ReadLine();
            Console.WriteLine();

            // Console.WriteLine(user + " " + pass);

            bool existe = false;
            int donde = 0;

            for(int a=0; a<users.Length; a++)
            {
                if (user == users[a])
                {
                    existe = true;
                    donde = a;
                }
            }


            if (existe && pass == claves[donde])
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Bienvenido "+user+"!");
            }

            if (existe && pass != claves[donde])
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Clave Incorrecta!");
            }

            if (!existe)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Usuario Incorrecto!");
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
        }
    }
}

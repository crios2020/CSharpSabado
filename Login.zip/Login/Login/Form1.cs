﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            //Evento Limpiar
            txtUsuario.Text = "";
            txtPassword.Text = "";
            lblInfo.Text = "";
            txtUsuario.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            String[] users = { "Juan", "Maria", "Jose", "Ana" };
            String[] claves = { "123", "abc", "321", "111" };

            string user = txtUsuario.Text;
            string pass = txtPassword.Text;
            
            bool existe = false;
            int donde = 0;

            for (int a = 0; a < users.Length; a++)
            {
                if (user == users[a])
                {
                    existe = true;
                    donde = a;
                }
            }


            if (existe && pass == claves[donde])
            {
                lblInfo.ForeColor = Color.Yellow;
                lblInfo.Text="Bienvenido " + user + "!";
            }

            if (existe && pass != claves[donde])
            {
                lblInfo.ForeColor = Color.Red;
                lblInfo.Text = "Clave Incorrecta!";
            }

            if (!existe)
            {
                lblInfo.ForeColor = Color.Red;
                lblInfo.Text = "Usuario Incorrecto!";
            }

        }

        bool ocultar = true;

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            ocultar = !ocultar;
            if (ocultar) txtPassword.PasswordChar = '*';
            else txtPassword.PasswordChar = (char)0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*
           Desafio 3
           Desarrollar el código que permita a una persona
           ingresar como máximo tres veces su contraseña. En
           caso de ingreso correcto deberá exhibirse la leyenda
           “Bienvenido!!”, caso contrario se mostrará “tres veces
           fallidas”.
           Indicar cuántas posibilidades de ingresar el código le
           queda. Por ejemplo, si tiene 2 posibilidades,
           informar "Tiene dos chances!" y si le queda una
           última oportunidad "Atención!! Última oportunidad!"
           */

            //String pass = "123";
            //for (int a = 1; a <= 3; a++)
            //{
            //    Console.WriteLine("Ingrese su password");
            //    if (a == 1) Console.WriteLine("hay 3 posibilidades!");
            //    if (a == 2) Console.WriteLine("Tiene dos chances!");
            //    if (a == 3) Console.WriteLine("Atención!! Última oportunidad!");
            //    String passIn = Console.ReadLine();
            //    if (pass == passIn)
            //    {
            //        Console.WriteLine("Bienvenido!!");
            //        break;
            //    }
            //    if (a == 3)
            //    {
            //        Console.WriteLine("tres veces fallidas");
            //    }
            //}


            //Console.WriteLine("-- Inicio Ejercicio 3 --");
            //Console.WriteLine();
            //string pass = "123";
            //string passIn;
            //int Intentos = 3;
            //do
            //{
            //    if (Intentos == 3) Console.Write("Ingrese su contraseña (Quedan 3 Intentos): ");
            //    if (Intentos == 2) Console.Write("Ingrese su contraseña (Quedan 2 Intentos): ");
            //    if (Intentos == 1) Console.Write("Ingrese su contraseña (Ultima Oportunidad!): ");
            //    passIn = Console.ReadLine();
            //    Intentos -= 1;
            //} while (passIn != pass && Intentos > 0);
            //Console.WriteLine();
            //if (passIn != pass) Console.WriteLine("-- Tres Veces Fallidas --");
            //else Console.WriteLine("-- Bienvenido!! --");
            //Console.WriteLine();
            //Console.WriteLine("-- Final Ejercicio 3 --"); //Use un Do While porque si o si va a tener que entrar al menos 1 vez al while 


            // Clase 5 Vectores - Arrays

            //declaración de vectores
            int[] numeros = new int[4];
            string[] nombres = new string[4];

            //asignación de valores o carga del vector
            //La primer posición de un vector tiene indice 0
            //La ultima posición de un vector tiene indice N - 1
            numeros[0] = 1;
            nombres[0] = "Juan";
            numeros[1] = 2;
            nombres[1] = "Lorena";
            numeros[2] = 3;
            nombres[2] = "Jose";
            numeros[3] = 4;
            nombres[3] = "Maria";

            // Error indice fuera de rango!!
            //numeros[4] = 5;
            //nombres[4] = "Ana";

            /*
             *          numeros             nombres                 indices
             *              1               Juan                    0
             *              2               Lorena                  1
             *              3               Jose                    2
             *              4               Maria                   3
             */

            Console.WriteLine(numeros[2] + " " + nombres[2]);
            Console.WriteLine("***************************");
            //Recorrido de un vector
            for (int a = 0; a < 4; a++)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }
            Console.WriteLine("***************************");
            //Recorrido de un vector usando while
            int b = 0;
            while (b < 4)
            {
                Console.WriteLine(numeros[b] + " " + nombres[b]);
                b++;
            }

            //Método length
            Console.WriteLine("Longitud de vector numeros: " +numeros.Length);

            Console.WriteLine("***************************");
            //Recorrido de un vector usando el método length
            for (int a = 0; a < numeros.Length; a++)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }

            Console.WriteLine("***************************");
            //Recorrido inverso
            for (int a=numeros.Length-1 ; a>=0 ; a--)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }

            //Declaración Abreviada
            String[] semana = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" };
            String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };
            int[] vector = { 10, 13, 29, 10, 23, 26, 30, 39, 38, 10, 65, 3, 6, 10, 34, 32 };

            for (int a = 0; a < semana.Length; a++) Console.WriteLine(semana[a]);
            for (int a = 0; a < meses.Length; a++) Console.WriteLine(meses[a]);
            for (int a = 0; a < vector.Length; a++) Console.WriteLine(vector[a]);

            //Mes del año
            Console.WriteLine(DateTime.Now.DayOfWeek);
            Console.WriteLine(((int)DateTime.Now.DayOfWeek));

            Console.WriteLine(semana[((int)DateTime.Now.DayOfWeek)]);
            Console.WriteLine(meses[DateTime.Now.Month-1]);

            Console.WriteLine("Hoy es "+ semana[(int)DateTime.Now.DayOfWeek] + " "+DateTime.Now.Day+" de "+ 
                            meses[DateTime.Now.Month - 1]+" de "+DateTime.Now.Year);

            //Totalizar un vector numerico, calcular promedio
            int total = 0;
            for (int a = 0; a < vector.Length; a++)
            {
                total += vector[a];
            }
            Console.WriteLine("Total: "+total);
            Console.WriteLine("Promedio: " + ((double)total / vector.Length));

            //Calcular Valores Máximos y Mínimos
            //int[] vector = { 10, 13, 29, 10, 23, 26, 30, 39, 38, 10, 6, 10, 34, 32 };
            int max = vector[0];
            int min = vector[0];

            for(int a = 1; a < vector.Length; a++)
            {
                if (max < vector[a]) max = vector[a];
                if (min > vector[a]) min = vector[a];
            }
            Console.WriteLine("Valor Máximo: " + max);
            Console.WriteLine("Valor Mínimo: " + min);

            //Sumar Números Pares
            //Sumar Números Impares
            //Contar cuantas veces se repite el nro 10
            int sumPares = 0;
            int sumImpares = 0;
            int cont10 = 0;

            //for (int a = 0; a < vector.Length; a++)
            //{
            //    if (vector[a] % 2 == 0)
            //    {
            //        sumPares += vector[a];
            //        if (vector[a] == 10)
            //        {
            //            cont10++;
            //        }
            //    }
            //    else
            //    {
            //        sumImpares += vector[a];
            //    }

            //}

            for (int a = 0; a < vector.Length; a++)
            {
                if (vector[a] % 2 == 0) sumPares += vector[a];
                else sumImpares += vector[a];
                if (vector[a] == 10) cont10++;
            }
            Console.WriteLine("Suma de Pares: " + sumPares);
            Console.WriteLine("Suma de Impares: " + sumImpares);
            Console.WriteLine("Cantidad nro 10: " + cont10);

            //int[] vector2 = vector;
            int[] vector2 = new int[vector.Length];
            
            //Copia de vectores
            Array.Copy(vector, vector2, vector.Length);

            //Recorro el vector vector
            for (int a = 0; a < vector2.Length; a++) Console.Write(vector2[a]+" - ");
            Console.WriteLine();

            //Ordenar un vector
            Array.Sort(vector2);

            //Recorro el vector vector
            for (int a = 0; a < vector2.Length; a++) Console.Write(vector2[a] + " - ");
            Console.WriteLine();

            //Revertir un vector
            Array.Reverse(vector2);

            //Recorro el vector vector
            for (int a = 0; a < vector2.Length; a++) Console.Write(vector2[a] + " - ");
            Console.WriteLine();

            //Recorro el vector vector
            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " - ");
            Console.WriteLine();

            //Copia de vectores
            int[] pares = { 2, 4, 6, 8, 10};
            int[] impares = new int[pares.Length];
            int[] pares2 = new int[pares.Length];

            /*
             *      pares               impares             pares2
             *          2                   _1_                _2_
             *          4                   _3_                _4_
             *          6                   _5_                _6_
             *          8                   _7_                _8_
             *         10                   _9_                10_
             */

            //Copiar los valores de pares a impares
            for (int a = 0; a < pares.Length; a++) impares[a] = pares[a]-1;


            for(int a = 0; a < pares.Length; a++)
            {
                Console.WriteLine(pares[a] + " " + impares[a]);
            }

            //Copiar vectores usando Array.Copy
            Array.Copy(pares, pares2,pares.Length);

            for (int a = 0; a < pares.Length; a++)
            {
                Console.WriteLine(pares[a] + " " + pares2[a]);
            }

            // Redimensionar un array o vector
            Array.Resize(ref numeros, 6);
            Array.Resize(ref nombres, 6);

            // Vectores numeros y nombres
            Console.WriteLine("Longitud de vector numeros: " + numeros.Length);
            Console.WriteLine("Longitud de vector nombres: " + nombres.Length);

            numeros[4] = 5;
            nombres[4] = "Leon";
            numeros[5] = 6;
            nombres[5] = "Nicolas";

            Console.WriteLine("***************************");
            //Recorrido de un vector usando el método length
            for (int a = 0; a < numeros.Length; a++)
            {
                Console.WriteLine(numeros[a] + " " + nombres[a]);
            }

            Console.WriteLine("Ingrese una cantidad:");
            String cantidad = Console.ReadLine();               // "5"
            int cant=Int32.Parse(cantidad);                     //  5
            String[] empleados = new string[cant];
            for(int a=0;a<empleados.Length; a++)
            {
                Console.WriteLine("Ingrese el nombre del empleado:");
                empleados[a] = Console.ReadLine();
            }
            for (int a = 0; a < empleados.Length; a++) Console.WriteLine(empleados[a]);

            Console.WriteLine("Presione una tecla para continuar.....");
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Clase 02

            //Constantes
            //Las constantes tienen una sola asignación de valor en el momento de la
            //declaración, y no puede volver a tener una nueva asignación de valor.
            //Pertenecen a algun tipo de datos conocido.
            //Por convención su nombre es en mayusculas.
            const float PI = 3.14f;
            //PI++;         //Error no se puede modificar una constante

            /*
             * Operadores Relacionales
             * 
             *  < <= > >=       operadores de comparación
             *  
             *  ==              operador equals
             *  
             *  !=              Not equals
             *  
             *  !               Not
             * 
             */

            int nro1 = 5;
            int nro2 = 7;
            int nro3 = 10;
            float nro4 = 5f;
            string nro5 = "5";

            Console.WriteLine(nro1 < nro2);       // true
            Console.WriteLine(nro2 <= nro1);    // false
            Console.WriteLine(nro1 == nro2);    // false
            Console.WriteLine(nro1 + 5 == nro3);// true
            Console.WriteLine(nro1 != nro2);    // true
            Console.WriteLine(nro1 + 2 != nro2);// false
            Console.WriteLine(!(nro1 < nro2));  // false
            Console.WriteLine(nro1 == nro4);    //true
            //Console.WriteLine(nro1 == nro5);    //Error


            bool log1 = true;
            bool log2 = false;

            Console.WriteLine(log1);            //true
            Console.WriteLine(!log1);           //false
            Console.WriteLine(!!log1);          //true
            Console.WriteLine(!!!log1);         //false
            Console.WriteLine(!!!!log1);        //true

            Console.WriteLine(log1 == log2);    //false
            Console.WriteLine(log1 != log2);    //true
            Console.WriteLine(log1 == !log2);   //true

            /*
             *    Tablas de verdad
             *    
             *      X       Y           OR          AND
             *      F       F           F           F
             *      F       V           V           F
             *      V       F           V           F
             *      V       V           V           V
             *      
             *      
             *      Operadores Logicos
             *      
             *      And         &&  
             *      OR          ||
             *      
             */

            Console.WriteLine(log1 || log2);        //true
            Console.WriteLine(log1 && log2);        //false

            Console.WriteLine(!log1 || log2);       //false
            Console.WriteLine(log1 && !log2);       //true



            Console.WriteLine(nro1 + 2 != nro2 || nro1 > nro2);

            // Operadores binarios & |
            Console.WriteLine(log1 || log2);        //true
            Console.WriteLine(log1 | log2);         //true

            Console.WriteLine(log2 && log1);        //false
            Console.WriteLine(log2 & log1);         //false


            //Estructura condicional IF
            if (log1)
            {
                //bloque de software o ambito de software
                Console.WriteLine("Verdad 1");
            }

            if (log1 == true)
            {
                Console.WriteLine("Verdad 2");
            }

            if (nro1 == 5)
            {
                Console.WriteLine("Verdad 3");
            }


            //Uso de llaves modo java
            if (log1) {
                Console.WriteLine("Verdad 4");
            }

            //Uso de llaves abreviado
            if (log1) Console.WriteLine("Verdad 5");

            // Estructura IF - ELSE

            if (log1)
            {
                Console.WriteLine("Verdad 6");
            }
            else
            {
                Console.WriteLine("Falso 6");
            }

            //Uso de llaves - modo JAVA
            if (log1) {
                Console.WriteLine("Verdad 7");
            } else { 
                Console.WriteLine("Falso 7");
            }

            //Uso de llaves abreviado
            if (log1)   Console.WriteLine("Verdad 8");
            else        Console.WriteLine("Falso 8");

            

            int mes=DateTime.Now.Month;
            Console.WriteLine(mes);
            if (mes == 1) Console.WriteLine("Enero");
            if (mes == 2) Console.WriteLine("Febrero");
            if (mes == 3) Console.WriteLine("Marzo");
            if (mes == 4) Console.WriteLine("Abril");
            if (mes == 5) Console.WriteLine("Mayo");
            if (mes == 6) Console.WriteLine("Junio");
            if (mes == 7) Console.WriteLine("Julio");
            if (mes == 8) Console.WriteLine("Agosto");
            if (mes == 9) Console.WriteLine("Septiembre");
            if (mes == 10) Console.WriteLine("Octubre");
            if (mes == 11) Console.WriteLine("Noviembre");
            if (mes == 12) Console.WriteLine("Diciembre");

            //Estructura SWITCH
            switch (mes)
            {
                case 1: 
                    Console.WriteLine("Enero");
                    Console.WriteLine("Verano");
                    break;
                case 2: 
                    Console.WriteLine("Febrero");
                    Console.WriteLine("Verano"); 
                    break;
                case 3: Console.WriteLine("Marzo"); break;
                case 4: Console.WriteLine("Abril"); break;
                case 5: Console.WriteLine("Mayo"); break;
                case 6: Console.WriteLine("Junio"); break;
                case 7: Console.WriteLine("Julio"); break;
                case 8: Console.WriteLine("Agosto"); break;
                case 9: Console.WriteLine("Septiembre"); break;
                case 10: Console.WriteLine("Octubre"); break;
                case 11: Console.WriteLine("Noviembre"); break;
                case 12: 
                    Console.WriteLine("Diciembre");
                    Console.WriteLine("Verano"); 
                    break;
                default: Console.WriteLine("Valor incorrecto"); break;
            }

            Console.WriteLine("Presione una tecla para continuar.....");
            Console.ReadKey();
        }
    }
}

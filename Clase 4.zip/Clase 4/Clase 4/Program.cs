﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Clase 04 
            //Estructura de repetición for

            int b = 1;
            Console.WriteLine("-- Inicio de Estructura While --");
            while (b <= 10)
            {
                Console.WriteLine(b);
                b++;
            }
            Console.WriteLine("-- Fin de la Estructura While --");
            Console.WriteLine(b);

            Console.WriteLine("-- Inicio de Estructura For --");
            for(int a=1; a<=10; a++)
            {
                Console.WriteLine(a);
            }
            Console.WriteLine("-- Fin de Estructura For --");
            //Console.WriteLine(a); //Error variable fuera de scope, fuera de alcance, se destruyo la variable a

            //uso de llaves modo java
            for(int a=1; a<=10; a++){
                Console.WriteLine(a);
            }

            //uso de llaves abreviados
            for (int a = 1; a <= 10; a++) Console.WriteLine(a);


            //Cambio de escala de recorrido
            for (int a = 1; a <= 10; a+=3)
            {
                Console.WriteLine(a);
                //a +=2;
            }

            //Formas de corte de recorrido
            for (int a = 1; a <= 10 && a<=5 ; a++)
            {
                Console.WriteLine(a);
                //if (a == 5) a = 15;
                //if (a == 5) break;
            }

            //Recorrido con variable global
            Console.WriteLine("-- Inicio de Estructura For --");
            for(b=1; b<=10; b++)
            {
                Console.WriteLine(b);
            }
            Console.WriteLine("-- Fin de Estructura For --");
            Console.WriteLine(b);           // 11

            //Recorrido con variable global desde 12 hasta 20
            Console.WriteLine("****************************************");
            for(b++; b<=20; b++)
            {
                Console.WriteLine(b);
            }
            Console.WriteLine("****************************************");

            //Recorrido con variable global desde 21 hasta 30
            for(; b<=30; b++)
            {
                Console.WriteLine(b);
            }
            Console.WriteLine("****************************************");

            //Recorrido de 1 a 10 omitiendo parametros en el for
            //Se puede hacer, pero no es recomendado.
            b = 1;
            for( ; ; )
            {
                Console.WriteLine(b);
                b++;
                if (b > 10) break;
            }

            // Recorrido con varias variables de control
            Console.WriteLine("****************************************");
            for (int r=1, s=1; r<=5 && s<=10; s++, r++)
            {
                Console.WriteLine(r + " " + s);
            }
            Console.WriteLine("****************************************");
            for (int r = 1, s = 1; r <= 5 || s <= 10; s++, r++)
            {
                Console.WriteLine(r + " " + s);
            }
            Console.WriteLine("****************************************");

            // for anidado
            //int cont = 0;
            //for(int r = 1; r<=10; r++)
            //{
            //    for(int s = 1; s<=10; s++)
            //    {
            //        for(int t=1;t<=10; t++)
            //        {
            //            cont++;
            //            Console.WriteLine(r+" "+s+" "+t+" "+cont);
            //        }
            //    }
            //}

            //Horas del reloj
            //for(int hora = 0; hora < 24; hora++)
            //{
            //    for(int minuto=0; minuto<60; minuto++)
            //    {
            //        for(int segundo=0; segundo<60; segundo++)
            //        {
            //            Console.WriteLine(hora+":"+minuto+":"+segundo);
            //        }
            //    }
            //}

            // loop infinito
            //for(int a=1; ; a++)
            //{
            //    Console.WriteLine(a);
            //}

            // loop infinito
            //for (int a = 1; truee ; a++)
            //{
            //    Console.WriteLine(a);
            //}

            // loop infinito
            //for (int a = 1; a<=10 ||false; a++)
            //{
            //    Console.WriteLine(a);
            //}

            // loop infinito
            //for (int a = 1; a <= 10 || a>0; a++)
            //{
            //    Console.WriteLine(a);
            //}

            // loop infinito
            //for (int a = 1; a <= 10; a++)
            //{
            //    Console.WriteLine(a--);
            //}

            // loop infinito
            //b = 2;
            //for (int a = 2; b <= 10; a++)
            //{
            //    Console.WriteLine(a);
            //}

            // loop infinito
            //b = 2;
            //for (int a = 2; a <= 10; b++)
            //{
            //    Console.WriteLine(a);
            //}

            /*
                Desafio 1
                Una persona desea invertir $1000 en un banco, el cual le otorga
                un 2% de interés mensual. ¿Cuál será la cantidad de dinero que
                esta persona tendrá al cabo de un año?
                En el primer mes tendrá acumulado 1000 $ más 20 $ de interés
                ( 2% de 1000 ). En el segundo mes se le sumará un 2% a la base
                de 1020 $ del mes anterior y así sucesivamente.
            */

            double capital = 1000;
            //for(int mes=1; mes<=12; mes++)
            //{
            //    capital = capital * 1.02;
            //    Console.WriteLine(Math.Round(capital, 2));
            //}
            //Console.WriteLine(Math.Round(capital,2));

            b = 1;
            while (b <= 12)
            {
                capital = capital * 1.02;
                b++;
            }
            Console.WriteLine(Math.Round(capital, 2));

            /*
                Desafio 2
                Una persona desea invertir $1000 en un banco, el
                cual le otorga un 3% de interés mensual.
                ¿En cuántos meses conseguirá $1200, si reinvierte
                cada mes todo su dinero?
            */
            capital = 1000;
            b = 1;
            //while (capital <= 1200)
            //{
            //    capital = capital * 1.03;
            //    b++;
            //}
            //Console.WriteLine(Math.Round(capital, 2));
            //Console.WriteLine("mes nro: " + b);

            //for(b=1; capital <= 1200; b++)
            //{
            //    capital = capital * 1.03;
            //}
            //Console.WriteLine("mes nro: " + b);

            for (b = 1; true; b++)
            {   
                if (capital >= 1200)
                {
                    Console.WriteLine("mes nro: " + b);
                    break;
                }
                capital = capital * 1.03;
            }

            /*
            Desafio 3
            Desarrollar el código que permita a una persona
            ingresar como máximo tres veces su contraseña. En
            caso de ingreso correcto deberá exhibirse la leyenda
            “Bienvenido!!”, caso contrario se mostrará “tres veces
            fallidas”.
            Indicar cuántas posibilidades de ingresar el código le
            queda. Por ejemplo, si tiene 2 posibilidades,
            informar "Tiene dos chances!" y si le queda una
            última oportunidad "Atención!! Última oportunidad!"
            */

            String pass = "123";
            for(int a=1; a<=3; a++)
            {
                Console.WriteLine("Ingrese su password");
                if (a == 1) Console.WriteLine("hay 3 posibilidades!");
                if (a == 2) Console.WriteLine("Tiene dos chances!");
                if (a == 3) Console.WriteLine("Atención!! Última oportunidad!");
                String passIn = Console.ReadLine();
                if (pass == passIn)
                {
                    Console.WriteLine("Bienvenido!!");
                    break;
                }
                if (a == 3)
                {
                    Console.WriteLine("tres veces fallidas");
                }
            }
            // Revisar la proxima semana!

            Console.WriteLine("Presione una tecla para continuar ....");
            Console.ReadKey();
        }
    }
}

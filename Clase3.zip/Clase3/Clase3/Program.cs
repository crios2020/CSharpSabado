﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Clase 3 Estructura de repeticion While

            int b = 1;
            //Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("** Inicio de estructura While **");
            while (b <= 10)
            {
                Console.WriteLine(b);
                b++;
            }
            Console.WriteLine("** Fin de la estructura While **");
            Console.WriteLine(b);

            //Uso de llaves modo java
            b = 1;
            while (b <= 10) {
                Console.WriteLine(b);
                b++;
            }

            //Uso de llaves abreviado
            b = 1;
            while (b <= 10) Console.WriteLine(b++);

            //loop infinito
            //b = 1;
            //while (true)
            //{
            //    Console.WriteLine(b);
            //    b++;
            //    //if (b >= 100) break;
            //}

            //loop infinito
            //b = 1;
            //while (b <= 10 || true)
            //{
            //    Console.WriteLine(b);
            //    b++;
            //}

            //loop infinito
            //b = 1;
            //while (b <= 10 || b>=1)
            //{
            //    Console.WriteLine(b);
            //    b++;
            //}

            //loop infinito
            //b = 1;
            //while (b <= 10)
            //{
            //    Console.WriteLine(b--);
            //    b++;
            //}

            // loop infinito
            //b = 1;
            //while (b <= 10) ;
            //{
            //    Console.WriteLine(b);
            //    b++;
            //}

            // Laratorio 

            // Imprimir los números del 1 al 10 salteando de 2 en 2
            Console.WriteLine("-- Laboratorio --");
            b = 1;
            while (b <= 10)
            {
                Console.WriteLine(b);
                b += 2;
            }

            // Imprimir los números de 10 al 1
            Console.WriteLine("-- Laboratorio --");
            b = 10;
            while (b >=1)
            {
                Console.WriteLine(b);
                b--;
            }


            // Ejemplo de while
            b = 20;
            Console.WriteLine("-- Inicio de Estructura While --");
            while (b <= 10)
            {
                Console.WriteLine(b);
                b++;
            }
            Console.WriteLine("-- Final de Estructura While --");
            Console.WriteLine(b);

            // Estructura do while
            b = 20;
            Console.WriteLine("-- Inicio de Estructura do while --");
            do
            {
                Console.WriteLine(b);
                b++;
            } while (b <= 10);
            Console.WriteLine("-- Fin de Estructura do while --");
            Console.WriteLine(b);

            // Laboratorio 
            Console.WriteLine("-- Laboratorio --");
            // Dado el siguiente código
            int a = 10;
            b = -2;
            int c = 5;
            //Siempre hay dos números positivos y uno negativo.
            //Informar la multiplicación de los dos números positivos.
            //if (a<0)
            //{
            //    Console.WriteLine("Valor = {0} ", (b * c));
            //}
            //else
            //{
            //    if (b < 0)
            //    {
            //        // if anidado
            //        Console.WriteLine("Valor = {0} ", (a * c));
            //    } 
            //    else
            //    {
            //        Console.WriteLine("Valor = {0} ", (a * b));
            //    }
            //}

            if (a < 0) Console.WriteLine(b * c);
            if (b < 0) Console.WriteLine(a * c);
            if (c < 0) Console.WriteLine(a * b);

            //Laboratorio
            //Imprimir los números del 1 al 10 
            //sin imprimir los números 2 5 y 9
            //Requisito: se deben conocer los operadores && y !=

            b = 1;
            while (b <= 10)
            {
                //if (b!=2 && b!=5 && b!=9) Console.WriteLine(b);

                if(b==2 || b==5 || b == 9)
                {
                    b++;
                    continue;
                }

                Console.WriteLine(b);
                b++;
                
            }

            // Break Continue
            b = 1;
            while (b <= 20)
            {
                // no imprimir el 6
                if (b == 6)
                {
                    b++;
                    continue;
                }

                //Cortar en el nro 14
                if (b == 14) break;

                Console.WriteLine(b);
                b++;
            }

            // Operador Resto %
            Console.WriteLine(15 % 2);      // 1
            Console.WriteLine(14 % 2);      // 0
            Console.WriteLine(-14 % 2);     // 0
            Console.WriteLine(-15 % 2);     //-1

            // Laboratorio
            // Imprimir la suma de números del 1 al 10
            Console.WriteLine(1+2+3+4+5+6+7+8+9+10);

            int resultado = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10;
            Console.WriteLine(resultado);

            b = 1;
            int total = 0;          //acumulador
            while (b <= 10)
            {
                total += b;
                b++;
            }
            Console.WriteLine(total);


            // Laboratorio
            // Imprimir la suma de números pares del 1 al 25
            b = 1;
            total = 0;
            while (b<=25)
            {
                if (b % 2 == 0) total += b;
                b++;
            }
            Console.WriteLine(total);

            Console.WriteLine("Presione una tecla para continuar....");
            Console.ReadKey();
        }
    }
}

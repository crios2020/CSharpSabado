﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase01Login
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             * Mi primer Login.
             * Ingresar por consola el usuario y clave.
             * user: root pass: 123
             */

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("***********************************************************");
            Console.WriteLine("*       B I E N V E N I D O S                             *");
            Console.WriteLine("***********************************************************");
            Console.WriteLine();
            Console.Write("Ingrese su Usuario: ");
            string user = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Ingrese su Clave: ");
            string pass = Console.ReadLine();
            Console.WriteLine();

            // Console.WriteLine(user + " " + pass);

            //if (user == "root")
            //{
            //    if (pass == "123")
            //    {
            //        Console.ForegroundColor = ConsoleColor.Yellow;
            //        Console.WriteLine("Bienvenido Usuario!");
            //    }
            //    else
            //    {
            //        Console.ForegroundColor = ConsoleColor.Red;
            //        Console.WriteLine("Clave Incorrecta!");
            //    }
            //} 
            //else
            //{
            //    Console.ForegroundColor = ConsoleColor.Red;
            //    Console.WriteLine("Usuario Incorrecto!");
            //}

            if (user == "root" && pass == "123")
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Bienvenido Usuario!");
            }

            if (user == "root" && pass != "123")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Clave Incorrecta!");
            }

            if (user != "root")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Usuario Incorrecto!");
            }
       
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
        }
    }
}
